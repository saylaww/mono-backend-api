<?php


namespace App\Response;


abstract class Test
{
    public static $START = 'STUDENT';




}
