<?php

namespace Database\Seeders;

use App\Models\GroupStudent;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class GroupStudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
//        GroupStudent::factory(15)->create();
    }
}
